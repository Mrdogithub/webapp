<template>
<div>
  <bar v-bind="{ 'title': '选择服务类型','allIconStatus': false, 'goBackIcon': true}"></bar>

	<div class="content-wrapper">
		<div class="input-wrapper">
			<p class="input-title">车主信息</p>
			<Input v-model="name" placeholder=" " class="input-item"></Input>
			<Input v-model="phoneNumber" placeholder=" " class="input-item inputevenHook"></Input>
		</div>
		<div class="input-wrapper">
			<p class="input-title">当前里程</p>
			<Input v-model="mileage" placeholder="Enter your Odometer" class="input-item">
   				<span slot="prepend" style="display:none"></span>
        		<span slot="append">km</span>
			</Input>
		</div>
		<div class="input-wrapper">
			<p class="input-title">服务类型</p>
			<RadioGroup v-model="vertical" vertical style="border: 1px solid #dddee1;">
				<div class="select-item">
					<Radio label="Schedule Service">
						<span class="radio-text">保养</span>
						<span class="server-type-detail" v-on:click="showServiceDetail"><Icon type="ios-information-outline"></Icon></span>
					</Radio>
				</div>
				<div class="select-item">
					<Radio label="Small Repairs">
						<span class="radio-text">维修</span>
					</Radio>
				</div>
				<div class="select-item">
					<Radio label="Inspection">
						<span class="radio-text">检查</span>
					</Radio>
				</div>
				<div class="select-item" style="border-bottom:none">
					<Radio label="others">
						<span class="radio-text">其他</span>
					</Radio>
				</div>
			</RadioGroup>
		</div>
		<div class="input-wrapper">
			<p class="input-title">服务顾问</p>
			<Input v-model="consultant" placeholder="Enter your Odometer" class="input-item" @click="showSelect"></Input>
		</div>
		<div class="input-wrapper">
			<p class="input-title">注意事项</p>
			<Input v-model="note" type="textarea" class="textAreaSize" placeholder="您是否需要其他服务……"></Input>
		</div>
  	</div>

	<div class="largeBtnWrapper">
		<router-link to="selectDateAndTime">
			<Button type="primary" size="large" class="largeBtn" >请选择服务日期和时段 </Button>
		</router-link>
		<router-link to="previewOrderSummary">
			<Button type="primary" size="large" class="largeBtn" >Preview Order Summary </Button>
		</router-link>
	</div>

</div>
</template>

<script>
import bar from '../components/bar'
export default {
    props: {},
	data () {
		return {
			month: 2,
			Hidden: false,
			vertical: 'apple',
			name: '',
			phoneNumber: '',
			mileage: '',
			consultant: '',
			note: ''
		}
    },
    components: {
		'bar': bar
    },
	methods: {
		showSelect () {},
		showServiceDetail () {
			console.log(this.name)
			console.log(this.phoneNumber)
			console.log(this.mileage)
			console.log(this.consultant)
			this.$router.push({name: 'selectServiceDetail'})
		}
	}
}
</script>
<style lang="stylus" rel="stylesheet/stylus">
	.bar
		height:60px
		background:rgb(69,150,164)
		padding-top:22px
		border-radius 15px 15px 0 0
	.bar-title
		text-align:center
		font-size:17px
		color:#fff
	.largeBtnWrapper
		margin-top:20px
		text-align:center
	.largeBtn
		width:90.1333%
		height 55px
	.inputevenHook .ivu-input
		border-top:none
	
	.ivu-input
		height:55px
		width: 100%
		border-radius:0px
		border-left:none
		border-right:none
	.ivu-radio-group
		width:100%
	.ivu-radio-group-vertical .ivu-radio-wrapper
		height:55px
		line-height:55px
	
	.select-item
		position:relative
		width: 85.7333%
		height:55px
		margin:0 auto
		line-height:55px	
		border-bottom:1px solid #dddee1
	.radio-text{
		position:absolute
		left:0px
	}
	.ivu-radio{
		position:absolute
		right:0px
		top:18px
	}
	.ivu-input:hover
		border-top-color: #57a3f3
		border-bottom-color: #57a3f3
	.ivu-input-group-prepend
		display:none
	.ivu-input-group-append, .ivu-input-group-prepend
		background-color:#fff
		border-right:none
		border-radius: 0px;
	textarea.ivu-input
		width:90.1333%
		border:1px solid #dddee1
		border-radius:4px
	.content-wrapper
		font-size:14px
		color:rgb(149,149,149)
	.server-type-detail
		position: absolute;
		left: 30%;
		top:2%
		width: 50px;
		font-size: 21px;
		color:rgb(45,150,205)
	.input-title
		height:50px
		font-size:14px
		color:rgb(149,149,149)
		line-height:50px
		background:rgb(249,252,255)

	.radio-text
		font-size: 14px
</style>

