<template>
<div v-show = "requestConfirmationStatus" class="requestConfirmation">
  <bar v-bind="{ 'title': 'Request Confirmation','goBackIcon': false}"></bar>
	<div class="content-wrapper">
		<div>
			<img src="" width="87.2" height="68.6" style="margin-top:150px;"/>
			<h2 class="request-title">Request Confirmed</h2>
			<p class="text-content">
				Your servicing request has been submitted.
				Please  sent your vehicle to dealer at:
			</p>
			<p class="text-content">
				Jiu He Car Sales Co,.Ltd.
				2129 Jin Sha Jiang Lu
				Putuo Qu,Shang hai20033
				Call Dealer: 021-5078623
			</p>
			<p class="text-content"> 
				Appointment Time:
				Thu,Mar 2 at 08:30
			</p>
		</div>	
		<div class="largeBtnWrapper">
			<div>
				<Button type="primary" size="large" class="largeBtn" >Save to Reminder</Button>
			</div>
			<div class="btn-wrapper modifyOrder">
				
				<router-link to="/myAppointment">
					<Button type="primary" size="large" class="largeBtn" >OK</Button>
				</router-link>
			</div>
		</div>
	</div>

	<div class="content-wrapper">
		<div>
			<img src="" width="87.2" height="68.6" style="margin-top:150px;"/>
			<h2 class="request-title">Request Failed</h2>
			<p class="text-content">
				Your servicing request has failed to submit.
				Please try angin.
			</p>
		</div>	
		<div class="largeBtnWrapper">
			<div>
				<router-link to="/">
					<Button type="primary" size="large" class="largeBtn" >Try Again</Button>
				</router-link>
			</div>
			<div class="btn-wrapper modifyOrder">
				<Button type="primary" size="large" class="largeBtn" >Cancel</Button>
			</div>
		</div>
	</div>
</div>
</template>

<script>
import bar from '../components/bar'
export default {
    props: {},
	data () {
		return {
			requestConfirmationStatus: false
		}
    },
    components: {
      'bar': bar
    },
	methods: {
		showRequestConfirmationStatus (status) {
			console.log(status)
			this.requestConfirmationStatus = status
		}
	}
}
</script>
<style lang="stylus" rel="stylesheet/stylus">
	.requestConfirmation
		position: absolute
		top: 0px
		background: #fff
		width: 100%
		z-index: 999
	.bar
		height:60px
		background:rgb(69,150,164)
		padding-top:22px
		border-radius 15px 15px 0 0
	.bar-title
		text-align:center
		font-size:17px
		color:#fff
	.largeBtnWrapper
		margin-top:60px
		text-align:center
	.largeBtn
		width:90.1333%
		height 55px
	.request-title
		width:325px
		text-align:center
		margin:0 auto;
		margin-top:27.4px
		margin-bottom:27.4px
		color:rgb(12,55,94)
		font-size:17px
		font-weight:normal
	.text-content
		width:325px
		text-align:center
		margin:0 auto
		margin-bottom:10px
		font-size:14px
		color:rgb(51,51,51)
	.btn-wrapper
		margin-top:17px
	.ivu-btn-primary
		font-size:17px
		background:rgb(45,150,205)
		border-color:rgb(45,150,205)
	.modifyOrder .ivu-btn-primary
		font-size:17px
		color:rgb(45,150,205)
		background:#fff
		border-color:rgb(45,150,205)
</style>

