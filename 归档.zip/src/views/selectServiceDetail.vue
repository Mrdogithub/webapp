<template>
  <div>
        <bar v-bind="{ 'title': '保养套餐详情','allIconStatus': false, 'goBackIcon': true}"></bar>
        <div class="content-wrapper">
            <ul class="detail-list-wrapper">
                <li class="detail-list-item" v-on:click="showServicePackage()">5000 km service package<span><Icon type="ios-arrow-forward"></Icon></span></li>
                <li class="detail-list-item">5000 km service package<span><Icon type="ios-arrow-forward"></Icon></span></li>
                <li class="detail-list-item">5000 km service package<span><Icon type="ios-arrow-forward"></Icon></span></li>
                <li class="detail-list-item">5000 km service package<span><Icon type="ios-arrow-forward"></Icon></span></li>
                <li class="detail-list-item">5000 km service package<span><Icon type="ios-arrow-forward"></Icon></span></li>
                <li class="detail-list-item">5000 km service package<span><Icon type="ios-arrow-forward"></Icon></span></li>
                <li class="detail-list-item">5000 km service package<span><Icon type="ios-arrow-forward"></Icon></span></li>
            </ul>
        </div>
        <div class="server-package-wrapper" v-show="showFlag">
            <div class="server-package-content-wrapper">
                <h1 class="server-package-title">服务套餐</h1>
                <div class="server-package-content">
                    <div class="content-item">
                        <h2>check</h2>
                        <div class="content-item-wrapper">
                            <p>1 机油滤清器* （6个月^）</p>
                            <p>2 发动机机油（6个月^）</p>
                            <div class="note">
                                <small><sup>*</sup>建议恶劣环境缩短周期</small>
                                <small><sup>^</sup>最长保养时间间隔</small>
                            </div>
                        </div>   
                    </div>

                    <div class="content-item">
                        <h2>Replace</h2>
                        <div class="content-item-wrapper">
                            <p>1 机油滤清器* （6个月^）</p>
                            <p>2 发动机机油（6个月^）</p>
                            <div class="note">
                                <small><sup>*</sup>建议恶劣环境缩短周期</small>
                                <small><sup>^</sup>最长保养时间间隔</small>
                            </div>
                        </div>   
                    </div>
                    <div class="largeBtnWrapper">
                        <Button type="primary" size="large" class="largeBtn" v-on:click="hideServicePackage">OK</Button>
                    </div>
                </div>
            </div>
	    </div>
  </div>
</template>

<script>
import bar from '../components/bar'
import servicePackage from '../components/servicePackage'
export default {
    props: {
        showFlag: {
            type: Boolean
        }
    },
    data () {
        return {
        }
    },
    components: {
        'bar': bar,
        'servicePackage': servicePackage
    },
    methods: {
        showServicePackage () {
            this.showFlag = true
        },
        hideServicePackage () {
            this.showFlag = false
        }
    }
}
</script>
<style lang="stylus" rel="stylesheet/stylus">
    .detail-list-wrapper
        width:100%
    .detail-list-item
        position:relative
        height:55px
        width:86.6666%
        margin:0 auto
        line-height:55px
        text-align:left
        font-size:14px
        border-bottom:1px solid #dddee1
    .detail-list-item span
        position:absolute
        right:0px;
        color:rgb(45,152m205)
    .server-package-wrapper
        position:fixed
        top:0px
        width:100%
        height:100%
        left:0
        z-index:100
        overflow:auto
        backdrop-filter:blur
        background:rgba(7,17,27,0.8)
    .server-package-content-wrapper
        width:91.2%
        min-height: 90%;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        margin: auto;
        border-radius: 18px;
        background-color:rgb(249,252,255)
    .server-package-title
        width:100%
        height:61px
        line-height:61px
        border-bottom:1px solid rgb(219,219,219)
        font-size:17px
        font-weight:normal
        color:rgb(18,78,132)
    .content-item
        &>h2
            height:58px
            line-height:58px
            font-size:18px
            font-weight:normal
        &>.content-item-wrapper
            width:100%
            height:auto
            padding:37px
            text-align:left
            box-sizing:border-box
            border-top:1px solid rgb(219,219,219)
            border-bottom:1px solid rgb(219,219,219)
        .content-item-wrapper
            background-color:#fff
            &>p
                color:#000
                font-size:18px
                font-weight:normal
            &>.note
                margin-top:16.8px
                &>small
                    display:block
                    color:rgb(155,155,155)
                    font-size:14px
                &>sup
                    margin-right:5px
	.largeBtnWrapper
		margin-top:20px
		text-align:center
	.largeBtn
		width:77.7777%
		height:55px


</style>
